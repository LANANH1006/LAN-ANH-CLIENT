package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.util.math.MathHelper;
import net.minecraft.util.math.Vec3d;

/** Khi bật: người chơi nào nằm trong vòng tròn (FOV) thì tự xoay tầm nhìn về phía họ. */
public class Aimbot {
    static float wrap(float a) { return MathHelper.wrapDegrees(a); }

    public static void toggle(MinecraftClient mc) {
        Config.I.aimbot = !Config.I.aimbot; Config.save();
        Util.msg("Aimbot: " + (Config.I.aimbot ? "§aBẬT" : "§cTẮT"));
    }

    static float[] angles(MinecraftClient mc, Vec3d to) {
        Vec3d eye = mc.player.getEyePos();
        double dx = to.x - eye.x, dy = to.y - eye.y, dz = to.z - eye.z;
        double h = Math.sqrt(dx * dx + dz * dz);
        float yaw = (float) Math.toDegrees(Math.atan2(-dx, dz));
        float pitch = (float) -Math.toDegrees(Math.atan2(dy, h));
        return new float[]{yaw, pitch};
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I;
        if (!c.aimbot || !c.aimPlayers || mc.currentScreen != null) return;
        var p = mc.player;
        PlayerEntity best = null; double bestD = c.aimFov; float[] bestA = null;
        for (PlayerEntity o : mc.world.getPlayers()) {
            if (o == p || o.isSpectator() || !o.isAlive()) continue;
            if (p.distanceTo(o) > c.aimRange) continue;
            if (c.aimVisibleOnly && !p.canSee(o)) continue;
            float[] a = angles(mc, o.getPos().add(0, o.getHeight() * 0.7, 0));
            double dy = wrap(a[0] - p.getYaw()), dp = a[1] - p.getPitch();
            double dist = Math.sqrt(dy * dy + dp * dp);
            if (dist <= bestD) { bestD = dist; best = o; bestA = a; }
        }
        if (best == null) return;
        float s = (float) Math.max(0.05, Math.min(1.0, c.aimSmooth));
        p.setYaw(p.getYaw() + wrap(bestA[0] - p.getYaw()) * s);
        p.setPitch(MathHelper.clamp(p.getPitch() + (bestA[1] - p.getPitch()) * s, -90f, 90f));
    }
}
