package com.safeanchor;

import net.minecraft.client.MinecraftClient;
import net.minecraft.client.option.Perspective;
import net.minecraft.entity.player.PlayerEntity;
import net.minecraft.item.Items;
import net.minecraft.network.packet.c2s.play.ClientCommandC2SPacket;
import net.minecraft.util.Hand;
import net.minecraft.util.math.Vec3d;

/**
 * Elytra + Mace tự động: cất cánh -> bay lên cao hơn đối thủ -> đổi cánh sang áo (để hết bay,
 * mace chỉ smash khi KHÔNG đang bay) -> rơi xuống đập -> đổi lại cánh -> lặp lại.
 */
public class ElytraMace {
    static boolean diving, keysHeld;
    static int stage;   // 0 = còn đeo cánh, bay (pháo) tới gần đối thủ; 1 = đã đổi áo, rơi đập
    static int cd, rocketCd;

    public static void toggle(MinecraftClient mc) {
        Config.I.autoMace = !Config.I.autoMace;
        if (!Config.I.autoMace) release(mc);
        Util.msg("Elytra Mace: " + (Config.I.autoMace ? "§aBẬT" : "§cTẮT"));
        Config.save();
    }

    static void release(MinecraftClient mc) {
        if (keysHeld) { mc.options.forwardKey.setPressed(false); mc.options.jumpKey.setPressed(false); keysHeld = false; }
        diving = false; stage = 0;
    }

    public static void tick(MinecraftClient mc) {
        Config c = Config.I;
        var p = mc.player;
        if (!c.autoMace || !c.enabled || p == null || mc.world == null || mc.interactionManager == null) { if (keysHeld) release(mc); return; }
        if (p.isSpectator() || p.isDead()) return;
        if (cd > 0) cd--;
        if (rocketCd > 0) rocketCd--;

        PlayerEntity t = Util.nearestEnemy(c.maceRange);
        if (t == null) { release(mc); return; }

        if (p.getHealth() + p.getAbsorptionAmount() < c.minSelfHealth) {
            release(mc);
            if (c.maceSwapChest && cd == 0 && Util.chestIs(Util::isElytra)) { Util.equipChest(Util::isChestplate, true); cd = 5; }
            Util.warn("Máu thấp - Elytra Mace tạm dừng");
            return;
        }

        switch (c.maceView) {
            case 1 -> mc.options.setPerspective(Perspective.FIRST_PERSON);
            case 2 -> mc.options.setPerspective(Perspective.THIRD_PERSON_BACK);
            case 3 -> mc.options.setPerspective(Perspective.THIRD_PERSON_FRONT);
            default -> {}
        }

        double above = p.getY() - t.getY();
        double horiz = Math.hypot(p.getX() - t.getX(), p.getZ() - t.getZ());
        double dist = Util.distToBox(p.getEyePos(), t.getBoundingBox());

        // tự đập luôn khi đối thủ trong tầm (dùng chung với bay)
        if (dist <= c.maceHitDist && p.getAttackCooldownProgress(0.5f) >= 0.9f && Util.has(s -> s.isOf(Items.MACE))) {
            if (Util.selectItem(s -> s.isOf(Items.MACE))) { mc.interactionManager.attackEntity(p, t); p.swingHand(Hand.MAIN_HAND); }
        }

        if (diving) { dive(mc, t, dist); return; }

        // ===== GIAI ĐOẠN BAY LÊN =====
        if (cd > 0) return;
        if (!Util.chestIs(Util::isElytra)) {
            if (Util.equipChest(Util::isElytra, false)) { cd = 3; } else { Util.warn("Không có elytra trong túi!"); }
            return;
        }
        if (p.isOnGround()) {                       // cất cánh
            mc.options.jumpKey.setPressed(true); keysHeld = true; return;
        }
        mc.options.jumpKey.setPressed(false);
        if (!p.isGliding()) {                       // bắt đầu bay giữa không trung
            if (p.getVelocity().y < 0) {
                p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                p.startGliding();
            }
            return;
        }
        Vec3d aim = new Vec3d(t.getX(), t.getY() + c.maceDiveDist + 8, t.getZ());
        Util.aim(p, aim);
        if (c.maceUseRocket && rocketCd == 0 && p.getVelocity().length() < 1.1 && Util.selectItem(s -> s.isOf(Items.FIREWORK_ROCKET))) {
            mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
            rocketCd = 14;
        }
        if (above >= c.maceDiveDist && horiz <= c.maceHorizDive) { diving = true; stage = 0; cd = 0; }
    }

    /** Bỏ lượt đập: đeo lại cánh và bay lên tiếp (không để chạm đất). */
    private static void abort(MinecraftClient mc) { release(mc); cd = 1; }

    private static void dive(MinecraftClient mc, PlayerEntity t, double dist) {
        Config c = Config.I; var p = mc.player;
        double horiz = Math.hypot(p.getX() - t.getX(), p.getZ() - t.getZ());
        double above = p.getY() - t.getY();
        if (!t.isAlive()) { abort(mc); return; }

        // ===== GIAI ĐOẠN 0: vẫn đeo cánh, dùng pháo bay tới sát đối thủ =====
        if (stage == 0) {
            if (!Util.chestIs(Util::isElytra)) {
                if (cd == 0 && Util.equipChest(Util::isElytra, false)) cd = 3;
                return;
            }
            if (!p.isGliding()) {
                if (p.isOnGround()) { abort(mc); return; }
                if (p.getVelocity().y < 0) {
                    p.networkHandler.sendPacket(new ClientCommandC2SPacket(p, ClientCommandC2SPacket.Mode.START_FALL_FLYING));
                    p.startGliding();
                }
                return;
            }
            if (horiz > c.maceHorizDive + 10 || above < 2) { abort(mc); return; }   // đối thủ chạy/pearl đi chỗ khác -> bay lên lại
            Util.aim(p, t.getPos().add(0, t.getHeight() * 0.5, 0));
            if (c.maceUseRocket && rocketCd == 0 && p.getVelocity().length() < 1.1 && Util.selectItem(s -> s.isOf(Items.FIREWORK_ROCKET))) {
                mc.interactionManager.interactItem(p, Hand.MAIN_HAND);
                rocketCd = 14;
            }
            if (dist <= c.maceSwapDist && above > 3) { stage = 1; cd = 0; }
            return;
        }

        // ===== GIAI ĐOẠN 1: đổi sang áo, rơi xuống đập =====
        if (horiz > c.maceAbortDist || above < 0) { abort(mc); return; }              // đối thủ dịch chuyển/lệch -> bay lên lại
        if (c.maceSwapChest && (p.isGliding() || Util.chestIs(Util::isElytra))) {
            if (cd == 0) { Util.equipChest(Util::isChestplate, true); cd = 2; }
            if (p.isGliding()) p.stopGliding();
            return;
        }
        if (!Util.selectItem(s -> s.isOf(Items.MACE))) { Util.warn("Không có mace!"); release(mc); return; }
        Util.aim(p, t.getPos().add(0, t.getHeight() * 0.5, 0));
        mc.options.forwardKey.setPressed(true); keysHeld = true;

        if (dist <= c.maceHitDist && p.getAttackCooldownProgress(0.5f) >= 0.9f) {
            mc.interactionManager.attackEntity(p, t);
            p.swingHand(Hand.MAIN_HAND);
            abort(mc);          // đập xong: đeo cánh lại, bay lên, đập tiếp (kiểu Wembu)
        }
    }
}
