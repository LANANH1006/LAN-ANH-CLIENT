package com.safeanchor;

import net.minecraft.block.Block;
import net.minecraft.client.MinecraftClient;
import net.minecraft.client.gui.DrawContext;
import net.minecraft.client.gui.screen.Screen;
import net.minecraft.client.gui.widget.ButtonWidget;
import net.minecraft.client.gui.widget.TextFieldWidget;
import net.minecraft.item.Item;
import net.minecraft.item.ItemStack;
import net.minecraft.item.Items;
import net.minecraft.registry.Registries;
import net.minecraft.text.Text;

import java.util.ArrayList;
import java.util.List;

/** Gõ tên (vd "log", "oak log") -> hiện danh sách block kèm hình, bấm để thêm/xóa khỏi ESP Block. */
public class BlockSearchScreen extends Screen {
    final Screen parent;
    TextFieldWidget field;
    final List<Block> results = new ArrayList<>();
    double scroll;
    static final int ROW = 24;

    public BlockSearchScreen(Screen parent) { super(Text.literal("Tìm block")); this.parent = parent; }

    int top() { return 56; }
    int bottom() { return height - 32; }

    @Override protected void init() {
        field = new TextFieldWidget(textRenderer, width / 2 - 110, 28, 220, 20, Text.literal("tìm"));
        field.setPlaceholder(Text.literal("gõ tên: log, oak log, diamond..."));
        field.setMaxLength(48);
        field.setChangedListener(s -> { scroll = 0; refresh(s); });
        addDrawableChild(field);
        setInitialFocus(field);
        addDrawableChild(ButtonWidget.builder(Text.literal("Xong"), b -> close()).dimensions(width / 2 - 60, height - 26, 120, 20).build());
        refresh(field.getText());
    }

    void refresh(String q) {
        results.clear();
        String[] words = q.toLowerCase().trim().split("\\s+");
        if (q.trim().isEmpty()) return;
        for (Block b : Registries.BLOCK) {
            Item it = b.asItem();
            if (it == Items.AIR) continue;
            String id = Registries.BLOCK.getId(b).getPath();
            String name = b.getName().getString().toLowerCase();
            boolean ok = true;
            for (String w : words) { if (w.isEmpty()) continue; if (!id.contains(w.replace(' ', '_')) && !name.contains(w)) { ok = false; break; } }
            if (ok) results.add(b);
            if (results.size() >= 300) break;
        }
    }

    @Override public void close() { Config.save(); MinecraftClient.getInstance().setScreen(parent); }

    @Override public void renderBackground(DrawContext ctx, int mx, int my, float d) { ctx.fill(0, 0, width, height, 0xE0101018); }

    @Override public void render(DrawContext ctx, int mx, int my, float d) {
        super.render(ctx, mx, my, d);
        ctx.drawCenteredTextWithShadow(textRenderer, Text.literal("Tìm block - bấm vào để thêm / xóa"), width / 2, 10, 0xFFB388FF);
        ctx.enableScissor(0, top(), width, bottom());
        for (int i = 0; i < results.size(); i++) {
            int y = (int) (top() + i * ROW - scroll);
            if (y + ROW < top() || y > bottom()) continue;
            Block b = results.get(i);
            String id = Registries.BLOCK.getId(b).getPath();
            boolean on = Config.I.espBlkCustom.contains(id);
            int x = width / 2 - 130;
            boolean hov = mx >= x && mx <= x + 260 && my >= y && my < y + ROW - 2;
            ctx.fill(x, y, x + 260, y + ROW - 2, on ? 0x80306030 : hov ? 0x80403060 : 0x80202030);
            ctx.drawItem(new ItemStack(b.asItem()), x + 4, y + 3);
            ctx.drawText(textRenderer, b.getName(), x + 28, y + 3, 0xFFFFFFFF, false);
            ctx.drawText(textRenderer, Text.literal(id), x + 28, y + 13, 0xFF9090A0, false);
            if (on) ctx.drawText(textRenderer, Text.literal("✔ đã thêm"), x + 200, y + 8, 0xFF55FF55, false);
        }
        ctx.disableScissor();
    }

    @Override public boolean mouseClicked(double x, double y, int b) {
        if (y >= top() && y <= bottom() && x >= width / 2.0 - 130 && x <= width / 2.0 + 130) {
            int i = (int) ((y - top() + scroll) / ROW);
            if (i >= 0 && i < results.size()) {
                String id = Registries.BLOCK.getId(results.get(i)).getPath();
                if (!Config.I.espBlkCustom.remove(id)) Config.I.espBlkCustom.add(id);
                Config.save();
                return true;
            }
        }
        return super.mouseClicked(x, y, b);
    }

    @Override public boolean mouseScrolled(double x, double y, double h, double v) {
        double max = Math.max(0, results.size() * ROW - (bottom() - top()));
        scroll = Math.max(0, Math.min(max, scroll - v * 20));
        return true;
    }
}
